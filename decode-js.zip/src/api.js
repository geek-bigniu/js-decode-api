const http = require('http');

function json_en(data) {
  return JSON.stringify(data);
}

const server = http.createServer((request, response) => {
  if (request.url === '/decode/v7' && request.method === 'POST') {
    let body = '';

    request.on('data', chunk => {
      body += chunk.toString(); // 转换Buffer到string
    });

    request.on('end', () => {
      try {
        const requestData = JSON.parse(body);
        const sourceCode = requestData.code;
        console.log('request come', sourceCode);
        // 解码
        let code;
        // 假设PluginSojsonV7.exportedFunction是您要调用的函数
        code = PluginSojsonV7.decode(sourceCode);

        response.writeHead(200, { 'Content-Type': 'application/json' });
        response.end(json_en({
          code: 1,
          msg: "success",
          data: code
        }));
      } catch (e) {
        console.error(e);
        response.writeHead(500, { 'Content-Type': 'application/json' });
        response.end(json_en({
          code: 0,
          msg: "系统错误"
        }));
      }
    });
  } else {
    response.writeHead(404, { 'Content-Type': 'application/json' });
    response.end(json_en({
      code: 0,
      msg: "Not Found"
    }));
  }
});

server.listen(8085, () => {
  console.log("listen on : 8085");
});

console.log('服务启动了~');
